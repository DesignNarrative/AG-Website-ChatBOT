/**
 * Abhinav Group AI Property Sales Chatbot Widget
 * Version: 1.0.0
 *
 * Vanilla JS — no framework dependencies.
 * Loads asynchronously, does not block page rendering.
 * Fully self-contained: injects its own HTML + CSS.
 *
 * Usage (via WordPress plugin or manual):
 *   <script>
 *     window.AbhinavChatConfig = { apiBase: 'https://api.example.com' };
 *   </script>
 *   <script src="abhinav-chatbot.min.js" defer></script>
 */

(function () {
  'use strict';

  /* ── Configuration ─────────────────────────────────────── */
  var cfg = window.AbhinavChatConfig || {};
  var API_BASE   = (cfg.apiBase   || 'http://localhost:8000').replace(/\/$/, '');
  var WIDGET_KEY = cfg.widgetKey  || '';          // Set in WordPress plugin settings
  var SOURCE_PAGE = cfg.sourcePage || window.location.href;
  var LANG        = cfg.lang      || 'auto';      // 'en' | 'hi' | 'auto'
  var POSITION    = cfg.position  || 'bottom-left';
  var BRAND_COLOR = cfg.brandColor || '#0284c7';  // Sky Blue primary
  var ACCENT_COLOR = cfg.accentColor || '#38bdf8'; // Sky Blue accent

  /* ── State ─────────────────────────────────────────────── */
  var state = {
    open: false,
    sessionToken: null,
    messages: [],
    isTyping: false,
    leadCaptured: false,
    leadStep: null,  // null | 'name' | 'phone' | 'confirm'
    leadData: {},
  };

  /* ── Translations ───────────────────────────────────────── */
  var T = {
    en: {
      title: 'Abhinav Group',
      subtitle: 'AI Assistant',
      online: 'We are online to assist you',
      placeholder: 'Type your message...',
      send: 'Send',
      welcome: 'Hello! Welcome to Abhinav Group. 🏠\n\nI\'m your AI property assistant. I can help you explore our projects, answer your questions, and assist you with your enquiries.\n\nHow may I help you today?',
      qr_projects: 'Explore Projects',
      qr_careers: 'Careers & Jobs',
      qr_supplier: 'Become a Supplier',
      qr_contact_team: 'Contact Our Team',
      lead_prompt: 'Would you like our sales team to contact you with more details?',
      lead_name: 'Please share your name:',
      lead_phone: 'Your 10-digit mobile number:',
      lead_email: 'Email address:',
      lead_project: 'Interested project:',
      lead_project_select: 'Select a project (optional)',
      lead_project_other: 'Other',
      lead_project_other_ph: 'Please specify project name',
      lead_confirm: 'Thank you! Our team will contact you shortly. 📞',
      lead_btn: 'Get a Callback',
      typing: 'Typing...',
      error: 'Connection issue. Please try again or call us at +91 9730397979.',
      powered: 'Powered by Abhinav Group AI',
      close: 'Close chat',
      open: 'Chat with us',
    },
    hi: {
      title: 'अभिनव ग्रुप',
      subtitle: 'AI असिस्टेंट',
      online: 'हम आपकी सहायता के लिए ऑनलाइन हैं',
      placeholder: 'अपना संदेश टाइप करें...',
      send: 'भेजें',
      welcome: 'नमस्ते! अभिनव ग्रुप में आपका स्वागत है। 🏠\n\nमैं आपका AI प्रॉपर्टी असिस्टेंट हूं।\n\nआज मैं आपकी कैसे सहायता कर सकता हूं?',
      qr_projects: 'प्रोजेक्ट देखें',
      qr_careers: 'करियर और नौकरियां',
      qr_supplier: 'सप्लायर बनें',
      qr_contact_team: 'हमारी टीम से संपर्क करें',
      lead_prompt: 'क्या आप चाहते हैं कि हमारी सेल्स टीम आपसे संपर्क करे?',
      lead_name: 'कृपया अपना नाम बताएं:',
      lead_phone: 'आपका 10 अंकों का मोबाइल नंबर:',
      lead_email: 'ईमेल आईडी:',
      lead_project: 'रुचि का प्रोजेक्ट:',
      lead_project_select: 'प्रोजेक्ट चुनें (वैकल्पिक)',
      lead_project_other: 'अन्य (Other)',
      lead_project_other_ph: 'कृपया प्रोजेक्ट का नाम लिखें',
      lead_confirm: 'धन्यवाद! हमारी टीम जल्द संपर्क करेगी। 📞',
      lead_btn: 'कॉलबैक के लिए अनुरोध करें',
      typing: 'टाइप हो रहा है...',
      error: 'कनेक्शन त्रुटि। कृपया पुनः प्रयास करें या +91 9730397979 पर कॉल करें।',
      powered: 'Abhinav Group AI द्वारा संचालित',
      close: 'चैट बंद करें',
      open: 'हमसे चैट करें',
    },
  };

  function t(key) {
    var lang = state.lang || 'en';
    return (T[lang] && T[lang][key]) ? T[lang][key] : (T.en[key] || key);
  }

  /* ── CSS Injection ──────────────────────────────────────── */
  function injectStyles() {
    var css = [
      /* Widget container */
      '#abhinav-chat-widget{position:fixed;z-index:999999;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;font-size:14px;line-height:1.5}',
      '#abhinav-chat-widget.pos-bottom-right{bottom:24px;right:24px}',
      '#abhinav-chat-widget.pos-bottom-left{bottom:24px;left:24px}',

      /* Launcher bubble */
      '#abhinav-chat-widget button#abhinav-launcher,#abhinav-launcher{all:unset!important;box-sizing:border-box!important;width:60px!important;height:60px!important;border-radius:50%!important;background:linear-gradient(135deg,' + BRAND_COLOR + ',' + ACCENT_COLOR + ')!important;cursor:pointer!important;display:flex!important;align-items:center!important;justify-content:center!important;box-shadow:0 4px 20px rgba(2,132,199,0.4)!important;border:none!important;padding:0!important;margin:0!important;transition:transform 0.2s,box-shadow 0.2s!important;position:relative!important}',
      '#abhinav-chat-widget button#abhinav-launcher:hover,#abhinav-launcher:hover{transform:scale(1.08)!important;box-shadow:0 6px 25px rgba(2,132,199,0.5)!important}',
      '#abhinav-launcher svg{width:30px;height:30px;fill:white;transition:opacity 0.2s}',
      '#abhinav-launcher .badge{position:absolute;top:-4px;right:-4px;width:18px;height:18px;border-radius:50%;background:#e53935;color:white;font-size:10px;font-weight:700;display:flex;align-items:center;justify-content:center;animation:ag-pulse 2s infinite}',
      '@keyframes ag-pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.15)}}',

      /* Chat panel */
      '#abhinav-chat-panel{width:360px;height:560px;background:white;border-radius:16px;box-shadow:0 8px 40px rgba(0,0,0,0.18);display:flex;flex-direction:column;overflow:hidden;transition:all 0.3s ease;transform-origin:bottom right}',
      '#abhinav-chat-panel.hidden{opacity:0;transform:scale(0.85) translateY(20px);pointer-events:none;position:absolute;bottom:70px;right:0}',
      '#abhinav-chat-panel.visible{opacity:1;transform:scale(1) translateY(0);position:absolute;bottom:70px;right:0}',
      '#abhinav-chat-widget.pos-bottom-left #abhinav-chat-panel{transform-origin:bottom left!important}',
      '#abhinav-chat-widget.pos-bottom-left #abhinav-chat-panel.hidden{left:0!important;right:auto!important}',
      '#abhinav-chat-widget.pos-bottom-left #abhinav-chat-panel.visible{left:0!important;right:auto!important}',

      /* Header */
      '#abhinav-header{background:linear-gradient(135deg,' + BRAND_COLOR + ' 0%,#0369a1 100%);padding:14px 16px;display:flex;align-items:center;gap:10px;flex-shrink:0}',
      '#abhinav-header-logo{width:38px;height:38px;border-radius:50%;background:white;display:flex;align-items:center;justify-content:center;font-weight:700;color:' + BRAND_COLOR + ';font-size:14px;flex-shrink:0;box-shadow:0 2px 6px rgba(0,0,0,0.1)}',
      '#abhinav-header-info{flex:1;min-width:0}',
      '#abhinav-header-title{color:white;font-weight:700;font-size:15px;margin:0}',
      '#abhinav-header-subtitle{color:rgba(255,255,255,0.85);font-size:11px;margin:0}',
      '#abhinav-header-status{display:flex;align-items:center;gap:5px;margin-top:2px}',
      '#abhinav-header-status .dot{width:7px;height:7px;border-radius:50%;background:#4caf50;animation:ag-pulse 2s infinite}',
      '#abhinav-header-status span{color:rgba(255,255,255,0.9);font-size:11px}',
      '#abhinav-chat-widget button#abhinav-close-btn,#abhinav-close-btn{all:unset!important;box-sizing:border-box!important;background:rgba(255,255,255,0.2)!important;border:none!important;color:white!important;cursor:pointer!important;padding:6px!important;border-radius:50%!important;width:30px!important;height:30px!important;display:flex!important;align-items:center!important;justify-content:center!important;flex-shrink:0!important;margin:0!important;box-shadow:none!important;transition:background 0.2s!important}',
      '#abhinav-chat-widget button#abhinav-close-btn:hover,#abhinav-close-btn:hover{background:rgba(255,255,255,0.35)!important}',

      /* Messages area */
      '#abhinav-messages{flex:1;overflow-y:auto;padding:16px 12px;display:flex;flex-direction:column;gap:10px;background:#f8fafc}',
      '#abhinav-messages::-webkit-scrollbar{width:4px}',
      '#abhinav-messages::-webkit-scrollbar-thumb{background:#cbd5e1;border-radius:4px}',

      /* Message bubbles */
      '.ag-msg{display:flex;flex-direction:column;max-width:82%;animation:ag-fadeUp 0.25s ease;flex-shrink:0}',
      '@keyframes ag-fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}',
      '.ag-msg.user{align-self:flex-end;align-items:flex-end}',
      '.ag-msg.bot{align-self:flex-start;align-items:flex-start;max-width:88%}',
      '.ag-bubble{padding:10px 14px;border-radius:18px;font-size:14px;line-height:1.5;white-space:pre-wrap;word-break:break-word}',
      '.ag-msg.user .ag-bubble{background:' + BRAND_COLOR + ';color:white;border-bottom-right-radius:4px}',
      '.ag-msg.bot .ag-bubble{background:white;color:#1e293b;border-bottom-left-radius:4px;box-shadow:0 1px 3px rgba(0,0,0,0.08)}',
      '.ag-bubble a{color:' + BRAND_COLOR + '!important;text-decoration:underline!important;font-weight:600!important;word-break:break-all!important;transition:color 0.15s}',
      '.ag-bubble a:hover{color:#0369a1!important;text-decoration:underline!important}',
      '.ag-msg.user .ag-bubble a{color:white!important;text-decoration:underline!important}',
      '.ag-time{font-size:10px;color:#94a3b8;margin-top:3px;padding:0 4px}',

      /* Typing indicator */
      '#abhinav-typing{align-self:flex-start;background:white;border-radius:18px;border-bottom-left-radius:4px;padding:12px 16px;box-shadow:0 1px 3px rgba(0,0,0,0.08);flex-shrink:0}',
      '#abhinav-typing span{display:inline-block;width:7px;height:7px;border-radius:50%;background:#94a3b8;margin:0 2px;animation:ag-bounce 1.2s infinite}',
      '#abhinav-typing span:nth-child(2){animation-delay:0.2s}',
      '#abhinav-typing span:nth-child(3){animation-delay:0.4s}',
      '@keyframes ag-bounce{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-6px)}}',

      /* Quick replies */
      '#abhinav-quick-replies{padding:8px 12px;display:flex;flex-wrap:wrap;gap:6px;background:#f8fafc;border-top:1px solid #e2e8f0;flex-shrink:0}',
      '#abhinav-chat-widget button.ag-qr,#abhinav-quick-replies button.ag-qr,.ag-qr{all:unset!important;box-sizing:border-box!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;background:white!important;background-color:white!important;border:1.5px solid ' + BRAND_COLOR + '!important;color:' + BRAND_COLOR + '!important;border-radius:20px!important;padding:6px 14px!important;font-size:12px!important;font-weight:600!important;font-family:inherit!important;line-height:1.4!important;letter-spacing:normal!important;text-transform:none!important;cursor:pointer!important;transition:all 0.2s!important;white-space:nowrap!important;box-shadow:none!important;margin:0!important;min-width:0!important;height:auto!important;width:auto!important}',
      '#abhinav-chat-widget button.ag-qr:hover,#abhinav-quick-replies button.ag-qr:hover,.ag-qr:hover{background:' + BRAND_COLOR + '!important;background-color:' + BRAND_COLOR + '!important;color:white!important;border-color:' + BRAND_COLOR + '!important;box-shadow:0 2px 8px rgba(2,132,199,0.25)!important}',

      /* Input area */
      '#abhinav-input-area{padding:12px;background:white;border-top:1px solid #e2e8f0;display:flex;gap:8px;flex-shrink:0;align-items:flex-end}',
      '#abhinav-input{flex:1;border:1.5px solid #cbd5e1;border-radius:24px;padding:10px 16px;font-size:14px;outline:none;resize:none;max-height:100px;font-family:inherit;transition:border-color 0.2s;line-height:1.4}',
      '#abhinav-input:focus{border-color:' + BRAND_COLOR + '}',
      '#abhinav-chat-widget button#abhinav-send,#abhinav-send{all:unset!important;box-sizing:border-box!important;width:40px!important;height:40px!important;border-radius:50%!important;background:' + BRAND_COLOR + '!important;border:none!important;color:white!important;cursor:pointer!important;display:flex!important;align-items:center!important;justify-content:center!important;flex-shrink:0!important;margin:0!important;padding:0!important;box-shadow:none!important;transition:background 0.2s!important;align-self:flex-end!important}',
      '#abhinav-chat-widget button#abhinav-send:hover,#abhinav-send:hover{background:#0369a1!important}',
      '#abhinav-chat-widget button#abhinav-send:disabled,#abhinav-send:disabled{background:#94a3b8!important;cursor:not-allowed!important}',
      '#abhinav-send svg{width:18px;height:18px;fill:white}',

      /* Lead capture form */
      '.ag-lead-card{background:white;border:1.5px solid ' + BRAND_COLOR + ';border-radius:12px;padding:14px;margin-top:4px;animation:ag-fadeUp 0.25s ease;box-shadow:0 2px 8px rgba(2,132,199,0.15);flex-shrink:0}',
      '.ag-lead-card p{margin:0 0 10px;color:#1e293b;font-size:13px}',
      '.ag-lead-input{width:100%;border:1.5px solid #cbd5e1;border-radius:8px;padding:9px 12px;font-size:13px;outline:none;box-sizing:border-box;font-family:inherit;transition:border-color 0.2s}',
      '.ag-lead-input:focus{border-color:' + BRAND_COLOR + '}',
      'select.ag-lead-input{background-color:white;color:#1e293b;cursor:pointer}',
      '#abhinav-chat-widget button.ag-lead-btn,.ag-lead-btn{margin-top:10px!important;width:100%!important;background:linear-gradient(135deg,' + BRAND_COLOR + ',#0369a1)!important;color:white!important;border:none!important;border-radius:8px!important;padding:10px!important;font-size:13px!important;font-weight:700!important;cursor:pointer!important;box-shadow:none!important;transition:opacity 0.2s!important}',
      '#abhinav-chat-widget button.ag-lead-btn:hover,.ag-lead-btn:hover{opacity:0.92!important}',

      /* Project card */
      '.ag-project-card{background:white;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;box-shadow:0 3px 12px rgba(0,0,0,0.08);margin-top:8px;margin-bottom:6px;animation:ag-fadeUp 0.25s ease;display:flex;flex-direction:column;flex-shrink:0;min-height:240px}',
      '.ag-project-card-img-wrap{width:100%;height:160px;background:#f1f5f9;overflow:hidden;position:relative;flex-shrink:0}',
      '.ag-project-card-img{width:100%;height:160px;min-height:160px;max-height:160px;object-fit:cover;display:block}',
      '.ag-project-card-body{padding:12px 14px;flex-shrink:0}',
      '.ag-project-card-title{font-weight:700;color:' + BRAND_COLOR + ';font-size:14px;margin:0 0 4px}',
      '.ag-project-card-info{font-size:12px;color:#64748b;margin:0 0 10px;line-height:1.4}',
      '#abhinav-chat-widget .ag-project-card-btn,.ag-project-card-btn{display:inline-block!important;background:linear-gradient(135deg,' + BRAND_COLOR + ',#0369a1)!important;color:white!important;border-radius:6px!important;padding:6px 14px!important;font-size:12px!important;font-weight:600!important;text-decoration:none!important;cursor:pointer!important;border:none!important;box-shadow:none!important;transition:opacity 0.2s!important}',
      '#abhinav-chat-widget .ag-project-card-btn:hover,.ag-project-card-btn:hover{opacity:0.92!important}',

      /* Footer */
      '#abhinav-footer{padding:6px;text-align:center;background:white;border-top:1px solid #f1f5f9}',
      '#abhinav-footer a{font-size:10px;color:#94a3b8;text-decoration:none}',
      '#abhinav-footer a:hover{color:' + BRAND_COLOR + '}',

      /* Mobile responsive (screens <= 600px) */
      '@media(max-width:600px){' +
        '#abhinav-chat-widget.pos-bottom-right{bottom:76px!important;right:16px!important}' +
        '#abhinav-chat-widget.pos-bottom-left{bottom:76px!important;left:16px!important}' +
        '#abhinav-launcher{width:56px!important;height:56px!important}' +
        '#abhinav-chat-widget.is-open{top:0!important;left:0!important;right:0!important;bottom:0!important;width:100%!important;height:100%!important;height:100dvh!important;max-height:100dvh!important;margin:0!important;padding:0!important}' +
        '#abhinav-chat-widget.is-open #abhinav-launcher{display:none!important}' +
        '#abhinav-chat-widget:has(#abhinav-chat-panel.visible) #abhinav-launcher{display:none!important}' +
        '#abhinav-chat-panel.visible{position:fixed!important;top:0!important;left:0!important;right:0!important;bottom:0!important;width:100%!important;max-width:100vw!important;height:100%!important;height:100dvh!important;max-height:100dvh!important;border-radius:0!important;box-shadow:none!important;transform:none!important;z-index:1000000!important;margin:0!important}' +
        '#abhinav-chat-panel.hidden{display:none!important}' +
        '#abhinav-header{border-radius:0!important;padding:12px 14px!important;padding-top:max(12px,env(safe-area-inset-top))!important}' +
        '#abhinav-messages{padding:14px 10px!important}' +
        '#abhinav-input-area{padding:10px 12px!important;padding-bottom:max(10px,env(safe-area-inset-bottom))!important}' +
        '#abhinav-footer{padding-bottom:max(6px,env(safe-area-inset-bottom))!important}' +
      '}',
    ].join('');

    var style = document.createElement('style');
    style.id = 'abhinav-chat-styles';
    style.textContent = css;
    document.head.appendChild(style);
  }

  /* ── SVG Icons ──────────────────────────────────────────── */
  var ICON_CHAT = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z" fill="white"/><path d="M12 2C7.58 2 4 5.58 4 10v2a2 2 0 0 0 2 2h.5v-4C6.5 6.96 8.96 4.5 12 4.5s5.5 2.46 5.5 5.5v4h.5a2 2 0 0 0 2-2v-2c0-4.42-3.58-8-8-8z" fill="white"/><path d="M18.5 12v3a2 2 0 0 1-2 2h-3v-1.5h3a.5.5 0 0 0 .5-.5v-3h1.5z" fill="white"/><path d="M12 13.5c-3.87 0-7 2.13-7 4.75V20h14v-1.75c0-2.62-3.13-4.75-7-4.75z" fill="white"/></svg>';
  var ICON_CLOSE = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>';
  var ICON_SEND = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>';

  /* ── HTML Structure ─────────────────────────────────────── */
  function buildHTML() {
    var posClass = 'pos-' + POSITION;
    var html = [
      '<div id="abhinav-chat-widget" class="' + posClass + '">',

      /* Chat panel */
      '<div id="abhinav-chat-panel" class="hidden" role="dialog" aria-label="Abhinav Group Chat">',

      /* Header */
      '<div id="abhinav-header">',
      '  <div id="abhinav-header-logo">AG</div>',
      '  <div id="abhinav-header-info">',
      '    <p id="abhinav-header-title">Abhinav Group</p>',
      '    <p id="abhinav-header-subtitle">' + t('subtitle') + '</p>',
      '    <div id="abhinav-header-status"><div class="dot"></div><span>' + t('online') + '</span></div>',
      '  </div>',
      '  <button id="abhinav-close-btn" aria-label="' + t('close') + '">' + ICON_CLOSE + '</button>',
      '</div>',

      /* Messages */
      '<div id="abhinav-messages"></div>',

      /* Quick replies */
      '<div id="abhinav-quick-replies"></div>',

      /* Input */
      '<div id="abhinav-input-area">',
      '  <textarea id="abhinav-input" rows="1" placeholder="' + t('placeholder') + '" aria-label="' + t('placeholder') + '"></textarea>',
      '  <button id="abhinav-send" aria-label="' + t('send') + '">' + ICON_SEND + '</button>',
      '</div>',

      /* Footer */
      '<div id="abhinav-footer"><a href="https://abhinavgroup.co.in" target="_blank" rel="noopener">' + t('powered') + '</a></div>',

      '</div>',  /* /chat-panel */

      /* Launcher */
      '<button id="abhinav-launcher" aria-label="' + t('open') + '">',
      '  ' + ICON_CHAT,
      '  <div class="badge">1</div>',
      '</button>',

      '</div>',  /* /widget */
    ].join('\n');

    var container = document.createElement('div');
    container.innerHTML = html;
    document.body.appendChild(container.firstChild);
  }

  /* ── DOM References ─────────────────────────────────────── */
  var el = {};
  function cacheEls() {
    el.widget       = document.getElementById('abhinav-chat-widget');
    el.panel        = document.getElementById('abhinav-chat-panel');
    el.launcher     = document.getElementById('abhinav-launcher');
    el.messages     = document.getElementById('abhinav-messages');
    el.quickReplies = document.getElementById('abhinav-quick-replies');
    el.input        = document.getElementById('abhinav-input');
    el.sendBtn      = document.getElementById('abhinav-send');
    el.closeBtn     = document.getElementById('abhinav-close-btn');
    el.badge        = el.launcher.querySelector('.badge');
  }

  /* ── Time Helper ────────────────────────────────────────── */
  function getTime() {
    var d = new Date();
    return d.getHours() + ':' + ('0' + d.getMinutes()).slice(-2) + (d.getHours() >= 12 ? ' PM' : ' AM');
  }

  /* ── Clean Message Formatting (Strip raw markdown artifacts like ###, ***) ── */
  function formatWidgetMessage(raw) {
    if (!raw) return '';
    // Strip markdown heading hashes (###, ##, #) at line start
    var cleaned = raw.replace(/^[#]{1,6}\s*/gm, '');
    // Strip horizontal dividers (---, ***, ___)
    cleaned = cleaned.replace(/^[*\-_]{3,}\s*$/gm, '');
    // Strip triple or more asterisks
    cleaned = cleaned.replace(/\*{3,}/g, '');
    // Trim extra consecutive newlines
    cleaned = cleaned.replace(/\n{3,}/g, '\n\n').trim();

    // Escape HTML first for XSS safety
    var safe = escapeHtml(cleaned);

    // Convert markdown links [text](url) to clickable <a>
  safe = safe.replace(/\[([^\]]+)\]\((https?:\/\/[^\s<>"'\)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer" style="color:#0284c7;text-decoration:underline;">$1</a>');

  // Convert raw URLs (http:// or https://) to clickable <a>
  safe = safe.replace(/(<a\s+[^>]*>[\s\S]*?<\/a>)|(https?:\/\/[^\s<>"'\)]+)/g, function (match, existingLink, url) {
    if (existingLink) return existingLink;
    return '<a href="' + url + '" target="_blank" rel="noopener noreferrer" style="color:#0284c7;text-decoration:underline;">' + url + '</a>';
  });

  // Convert bare project domains to clickable <a> (e.g. thecurvevirar.com, pebblesbusinessbay.com, abhinavgroup.co.in/samsara)
  safe = safe.replace(/(<a\s+[^>]*>[\s\S]*?<\/a>)|(thecurvevirar\.com[^\s<>"'\)]*|pebblesbusinessbay\.com[^\s<>"'\)]*|abhinavgroup\.co\.in[^\s<>"'\)]*)/g, function (match, existingLink, domain) {
    if (existingLink) return existingLink;
    return '<a href="https://' + domain + '" target="_blank" rel="noopener noreferrer" style="color:#0284c7;text-decoration:underline;">' + domain + '</a>';
  });

    // Convert **bold** to <strong>bold</strong>
    safe = safe.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');

    // Convert bullets (* item or - item) at start of lines into clean bullet • item
    safe = safe.replace(/^[*\-]\s+/gm, '• ');

    // Convert newlines to <br>
    safe = safe.replace(/\n/g, '<br>');

    return safe;
  }

  /* ── Render Messages ────────────────────────────────────── */
  function appendMessage(role, text, extra) {
    extra = extra || {};

    // Remove typing indicator if present
    var typingEl = document.getElementById('abhinav-typing');
    if (typingEl) typingEl.remove();

    var div = document.createElement('div');
    div.className = 'ag-msg ' + role;

    var bubble = document.createElement('div');
    bubble.className = 'ag-bubble';
    bubble.innerHTML = formatWidgetMessage(text);
    div.appendChild(bubble);

    var timeEl = document.createElement('div');
    timeEl.className = 'ag-time';
    timeEl.textContent = getTime();
    div.appendChild(timeEl);

    el.messages.appendChild(div);

    // Render project cards if present
    if (extra.project_cards && extra.project_cards.length) {
      extra.project_cards.forEach(function (card) {
        appendProjectCard(card);
      });
    }

    if (role === 'user') {
      state.lastUserMsgEl = div;
      scrollToBottom();
    } else {
      var scrollTarget = state.lastUserMsgEl || div;
      scrollToMessageStart(scrollTarget);
    }
  }

  function appendProjectCard(card) {
    var div = document.createElement('div');
    div.className = 'ag-project-card';
    var rawUrl = card.image_url || '';
    var fullUrl = rawUrl;
    if (fullUrl && !fullUrl.startsWith('http://') && !fullUrl.startsWith('https://')) {
      var base = API_BASE || (typeof window !== 'undefined' && window.location.origin ? window.location.origin : '');
      fullUrl = base ? base.replace(/\/$/, '') + (fullUrl.startsWith('/') ? '' : '/') + fullUrl : fullUrl;
    }
    var imgHtml = fullUrl
      ? '<div class="ag-project-card-img-wrap">' +
        '<img class="ag-project-card-img" src="' + escapeHtml(fullUrl) + '" alt="' + escapeHtml(card.name) + '" loading="eager" decoding="async" onerror="if(!this._retried && \'' + escapeHtml(rawUrl) + '\' !== this.src){this._retried=true; this.src=\'' + escapeHtml(rawUrl) + '\';}">' +
        '</div>'
      : '';
    div.innerHTML = imgHtml +
      '<div class="ag-project-card-body">' +
      '<p class="ag-project-card-title">' + escapeHtml(card.name) + '</p>' +
      '<p class="ag-project-card-info">' + escapeHtml(card.location || '') + (card.config ? ' · ' + card.config : '') + '</p>' +
      '<button class="ag-project-card-btn">' + (state.lang === 'hi' ? 'प्रोजेक्ट देखें' : 'View Project') + '</button>' +
      '</div>';
    var btn = div.querySelector('.ag-project-card-btn');
    if (btn) {
      btn.addEventListener('click', function (e) {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        if (card.url) window.open(card.url, '_blank');
      });
    }
    el.messages.appendChild(div);
  }

  function showTyping() {
    var typingEl = document.createElement('div');
    typingEl.id = 'abhinav-typing';
    typingEl.innerHTML = '<span></span><span></span><span></span>';
    el.messages.appendChild(typingEl);
    scrollToBottom();
  }

  function renderQuickReplies(replies) {
    el.quickReplies.innerHTML = '';
    if (!replies || !replies.length) return;
    replies.forEach(function (reply) {
      var btn = document.createElement('button');
      btn.className = 'ag-qr';
      btn.textContent = reply;
      btn.addEventListener('click', function (e) {
        if (e) {
          e.preventDefault();
          e.stopPropagation();
        }
        sendMessage(reply);
      });
      el.quickReplies.appendChild(btn);
    });
  }

  function showLeadCard() {
    if (state.leadCaptured) return;
    var existing = document.getElementById('ag-lead-form');

    // Normalize selectedProject to exact dropdown option values
    var rawProject = (state.lastProject || '').toLowerCase();
    var selectedProject = '';
    if (rawProject.indexOf('curve') !== -1) {
      selectedProject = 'The Curve';
    } else if (rawProject.indexOf('samsara') !== -1) {
      selectedProject = 'Samsara';
    } else if (rawProject.indexOf('business bay') !== -1) {
      selectedProject = 'Pebbles Business Bay';
    } else if (rawProject.indexOf('greenfield') !== -1 || rawProject.indexOf('pebbles') !== -1) {
      selectedProject = 'Pebbles Greenfield';
    } else if (state.lastProject === 'Other') {
      selectedProject = 'Other';
    }

    // Preserve any existing input if repositioning form to active bottom
    var prevName = '', prevPhone = '', prevEmail = '';
    if (existing) {
      var nInput = document.getElementById('ag-lead-name');
      var pInput = document.getElementById('ag-lead-phone');
      var eInput = document.getElementById('ag-lead-email');
      if (nInput) prevName = nInput.value || '';
      if (pInput) prevPhone = pInput.value || '';
      if (eInput) prevEmail = eInput.value || '';
      existing.remove();
    }

    var card = document.createElement('div');
    card.className = 'ag-lead-card';
    card.id = 'ag-lead-form';

    card.innerHTML =
      '<p>' + t('lead_name') + '</p>' +
      '<input class="ag-lead-input" id="ag-lead-name" type="text" placeholder="Your name" autocomplete="name" value="' + prevName.replace(/"/g, '&quot;') + '">' +
      '<p style="margin-top:10px">' + t('lead_phone') + '</p>' +
      '<input class="ag-lead-input" id="ag-lead-phone" type="tel" placeholder="10-digit mobile" autocomplete="tel" maxlength="13" value="' + prevPhone.replace(/"/g, '&quot;') + '">' +
      '<p style="margin-top:10px">' + t('lead_email') + '</p>' +
      '<input class="ag-lead-input" id="ag-lead-email" type="email" placeholder="name@example.com" autocomplete="email" value="' + prevEmail.replace(/"/g, '&quot;') + '">' +
      '<p style="margin-top:10px">' + t('lead_project') + '</p>' +
      '<select class="ag-lead-input" id="ag-lead-project" style="background-color:white;cursor:pointer;">' +
        '<option value="">' + t('lead_project_select') + '</option>' +
        '<option value="The Curve"' + (selectedProject === 'The Curve' ? ' selected' : '') + '>The Curve</option>' +
        '<option value="Samsara"' + (selectedProject === 'Samsara' ? ' selected' : '') + '>Samsara</option>' +
        '<option value="Pebbles Business Bay"' + (selectedProject === 'Pebbles Business Bay' ? ' selected' : '') + '>Pebbles Business Bay</option>' +
      '</select>' +
      '<button class="ag-lead-btn" id="ag-lead-submit">' + t('lead_btn') + '</button>';
    el.messages.appendChild(card);

    document.getElementById('ag-lead-submit').addEventListener('click', function (e) {
      if (e) {
        e.preventDefault();
        e.stopPropagation();
      }
      submitLead();
    });
  }

  function submitLead() {
    var name  = (document.getElementById('ag-lead-name').value || '').trim();
    var phone = (document.getElementById('ag-lead-phone').value || '').trim().replace(/\D/g, '');
    var email = (document.getElementById('ag-lead-email') ? document.getElementById('ag-lead-email').value || '' : '').trim();

    var projectSelect = document.getElementById('ag-lead-project');
    var projectVal = (projectSelect ? projectSelect.value || '' : '').trim();

    if (!name) {
      document.getElementById('ag-lead-name').style.borderColor = 'red';
      return;
    }
    if (phone.length < 10) {
      document.getElementById('ag-lead-phone').style.borderColor = 'red';
      return;
    }
    if (!email) {
      document.getElementById('ag-lead-email').style.borderColor = 'red';
      return;
    }

    state.leadData = { name: name, phone: phone, email: email, interested_project: projectVal || undefined };
    state.lastUserMsgEl = null;
    var formEl = document.getElementById('ag-lead-form');
    if (formEl) formEl.remove();

    // POST to leads API
    apiPost('/api/v1/leads/', {
      name: name,
      phone: phone,
      email: email || undefined,
      interested_project: projectVal || undefined,
      consent_to_contact: true,
      source_page: SOURCE_PAGE,
      session_token: state.sessionToken,
    }).then(function (data) {
      state.leadCaptured = true;
      appendMessage('bot', t('lead_confirm'));
      renderQuickReplies([t('qr_projects'), t('qr_contact_team')]);
    }).catch(function () {
      appendMessage('bot', 'Thank you! You can reach us directly at +91 9730397979.');
    });
  }

  function scrollToMessageStart(msgEl) {
    if (!el.messages || !msgEl) return;
    function align() {
      if (el.messages && msgEl) {
        var cRect = el.messages.getBoundingClientRect();
        var mRect = msgEl.getBoundingClientRect();
        var targetScroll = el.messages.scrollTop + (mRect.top - cRect.top) - 10;
        el.messages.scrollTop = Math.max(0, targetScroll);
      }
    }
    align();
    setTimeout(align, 60);
    setTimeout(align, 180);
  }

  function scrollToBottom() {
    if (el.messages) {
      el.messages.scrollTop = el.messages.scrollHeight;
    }
    setTimeout(function () {
      if (el.messages) {
        el.messages.scrollTop = el.messages.scrollHeight;
      }
    }, 50);
  }

  function escapeHtml(str) {
    return String(str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  /* ── API Calls ──────────────────────────────────────────── */
  function apiPost(path, data) {
    var headers = { 'Content-Type': 'application/json' };
    if (WIDGET_KEY) headers['X-Widget-Key'] = WIDGET_KEY;
    return fetch(API_BASE + path, {
      method: 'POST',
      headers: headers,
      body: JSON.stringify(data),
    }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    });
  }

  /* ── Send Message ───────────────────────────────────────── */
  function sendMessage(text) {
    text = (text || el.input.value || '').trim();
    if (!text || state.isTyping) return;

    el.input.value = '';
    el.input.style.height = 'auto';
    el.quickReplies.innerHTML = '';
    el.badge.style.display = 'none';

    appendMessage('user', text);
    state.isTyping = true;
    el.sendBtn.disabled = true;
    showTyping();

    var payload = {
      message: text,
      source_page: SOURCE_PAGE,
    };
    if (state.sessionToken) payload.session_token = state.sessionToken;

    apiPost('/api/v1/chat/message', payload)
      .then(function (data) {
        state.isTyping = false;
        el.sendBtn.disabled = false;

        if (data.session_token) state.sessionToken = data.session_token;
        if (data.language) state.lang = data.language;

        appendMessage('bot', data.reply, { project_cards: data.project_cards });

        // Show quick replies
        if (data.quick_replies && data.quick_replies.length) {
          renderQuickReplies(data.quick_replies);
        }

        // Track last mentioned project for lead form convenience
        var cardName = (data.project_cards && data.project_cards.length === 1 && data.project_cards[0].name) ? data.project_cards[0].name.toLowerCase() : '';
        if (data.intent === 'project_enquiry_curve' || cardName.indexOf('curve') !== -1) state.lastProject = 'The Curve';
        else if (data.intent === 'project_enquiry_samsara' || cardName.indexOf('samsara') !== -1) state.lastProject = 'Samsara';
        else if (data.intent === 'project_enquiry_business_bay' || cardName.indexOf('business bay') !== -1) state.lastProject = 'Pebbles Business Bay';
        else if (data.project_cards && data.project_cards.length === 1 && data.project_cards[0].name) {
          state.lastProject = data.project_cards[0].name;
        }

        // Offer lead capture after explicit intent: pricing, escalation, brochure, or after meaningful chat
        state.messages.push({ role: 'user', text: text });
        state.messages.push({ role: 'bot', text: data.reply });

        var leadIntents = [
          'pricing_enquiry', 'escalation', 'brochure_request', 'nri_enquiry',
          'project_enquiry_samsara', 'project_enquiry_greenfield',
          'project_enquiry_curve', 'project_enquiry_business_bay',
          'config_enquiry'
        ];
        if (!state.leadCaptured && leadIntents.indexOf(data.intent) !== -1) {
          setTimeout(showLeadCard, 700);
        } else if (!state.leadCaptured && state.messages.length >= 4) {
          setTimeout(showLeadCard, 900);
        }
      })
      .catch(function (err) {
        state.isTyping = false;
        el.sendBtn.disabled = false;
        var typingEl = document.getElementById('abhinav-typing');
        if (typingEl) typingEl.remove();
        appendMessage('bot', t('error'));
      });
  }

  /* ── Open / Close ───────────────────────────────────────── */
  function openWidget() {
    state.open = true;
    if (el.widget) el.widget.classList.add('is-open');
    el.panel.classList.remove('hidden');
    el.panel.classList.add('visible');
    el.launcher.querySelector('svg').style.opacity = '0';
    el.badge.style.display = 'none';

    // Auto-focus input on desktop only (screen width > 600px).
    // On mobile devices, auto-focus forces the on-screen keyboard to pop up immediately,
    // which covers half the screen and hides the welcome message and header.
    var isMobile = (window.innerWidth <= 600) || /Android|iPhone|iPad|iPod|webOS|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent || '');
    if (!isMobile) {
      el.input.focus();
    }

    // Show welcome message on first open
    if (state.messages.length === 0) {
      setTimeout(function () {
        showTyping();
        setTimeout(function () {
          var typingEl = document.getElementById('abhinav-typing');
          if (typingEl) typingEl.remove();
          appendMessage('bot', t('welcome'));
          renderQuickReplies([
            t('qr_projects'),
            t('qr_careers'),
            t('qr_supplier'),
            t('qr_contact_team'),
          ]);
        }, 900);
      }, 300);
    }
  }

  function closeWidget() {
    state.open = false;
    if (el.widget) el.widget.classList.remove('is-open');
    el.panel.classList.remove('visible');
    el.panel.classList.add('hidden');
    el.launcher.querySelector('svg').style.opacity = '1';
  }

  function toggleWidget() {
    if (state.open) closeWidget();
    else openWidget();
  }

  /* ── Event Listeners ────────────────────────────────────── */
  function bindEvents() {
    el.launcher.addEventListener('click', function (e) {
      if (e) e.stopPropagation();
      toggleWidget();
    });
    el.closeBtn.addEventListener('click', function (e) {
      if (e) e.stopPropagation();
      closeWidget();
    });
    el.sendBtn.addEventListener('click', function (e) {
      if (e) {
        e.preventDefault();
        e.stopPropagation();
      }
      sendMessage();
    });

    // Send on Enter (Shift+Enter = newline)
    el.input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        e.stopPropagation();
        sendMessage();
      }
    });

    // Auto-resize textarea
    el.input.addEventListener('input', function () {
      this.style.height = 'auto';
      this.style.height = Math.min(this.scrollHeight, 100) + 'px';
    });

    // Close on Escape key
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && state.open) closeWidget();
    });

    // Close on outside click (robust check against detached buttons & internal elements)
    document.addEventListener('click', function (e) {
      if (!state.open) return;
      if (!e || !e.target) return;
      // If clicked inside the launcher, ignore
      if (el.launcher && (el.launcher === e.target || el.launcher.contains(e.target))) return;
      // If clicked inside the chat panel, ignore
      if (el.widget && el.widget.contains(e.target)) return;
      // If clicked node was removed from DOM during event handling (e.g. quick reply cleared), ignore
      if (!document.body.contains(e.target)) return;
      // Check closest container if browser supports it
      if (e.target.closest && (e.target.closest('#abhinav-chat-panel') || e.target.closest('#abhinav-launcher') || e.target.closest('#abhinav-chat-widget'))) return;
      closeWidget();
    });
  }

  /* ── Init ───────────────────────────────────────────────── */
  function init() {
    // Set initial language
    state.lang = LANG === 'auto' ? 'en' : LANG;

    injectStyles();
    buildHTML();
    cacheEls();
    bindEvents();

    // Auto-open after delay if configured
    if (cfg.autoOpen) {
      setTimeout(openWidget, cfg.autoOpenDelay || 3000);
    }

    console.log('[AbhinavChat] Widget initialized. API:', API_BASE);
  }

  /* ── Boot ───────────────────────────────────────────────── */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // Expose public API for external control
  window.AbhinavChat = {
    open: openWidget,
    close: closeWidget,
    sendMessage: sendMessage,
  };

})();
